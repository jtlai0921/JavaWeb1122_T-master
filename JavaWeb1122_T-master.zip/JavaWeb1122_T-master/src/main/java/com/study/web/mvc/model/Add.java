package com.study.web.mvc.model;

public class Add {
    public int calc(int x, int y) {
        return x + y;
    }
}
